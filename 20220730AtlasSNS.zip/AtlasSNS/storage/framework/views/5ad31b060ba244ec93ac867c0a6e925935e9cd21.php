<?php $__env->startSection('content'); ?>

<!--↓バリデーションで引っ掛かるとエラーメッセージが表示される-->
<div>
  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
</div>

<?php echo Form::open(['url' => '/register']); ?>

<!--↑新規登録/登録後のページ遷移先の変更。新規ユーザー登録するページへの移行。urlを追記。-->

<h2>新規ユーザー登録</h2>

<?php echo e(Form::label('ユーザー名')); ?>

<?php echo e(Form::text('username',null,['class' => 'input'])); ?>


<?php echo e(Form::label('メールアドレス')); ?>

<?php echo e(Form::text('mail',null,['class' => 'input'])); ?>


<?php echo e(Form::label('パスワード')); ?>

<?php echo e(Form::text('password',null,['class' => 'input'])); ?>


<?php echo e(Form::label('パスワード確認')); ?>

<?php echo e(Form::text('password_confirmation',null,['class' => 'password_confirmation'])); ?>

<!--↑クラス名をpasswordから修正。修正前だと延々にバリデーションが効かずログインをぐるぐるする-->

<?php echo e(Form::submit('登録')); ?>


<p><a href="/login">ログイン画面へ戻る</a></p>

<?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/miyunakayama/Atlas_SNS_MiyuNakayama/AtlasSNS/resources/views/auth/register.blade.php ENDPATH**/ ?>