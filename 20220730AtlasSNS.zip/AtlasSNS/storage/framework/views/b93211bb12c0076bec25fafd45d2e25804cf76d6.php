<?php $__env->startSection('content'); ?>
<h2>ここに書く</h2h>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/miyunakayama/Atlas_SNS_MiyuNakayama/AtlasSNS/resources/views/follows/followList.blade.php ENDPATH**/ ?>