@extends('layouts.login')

@section('content')
<h2>ここに書く</h2h>

@endsection
